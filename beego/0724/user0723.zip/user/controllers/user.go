package controllers

import (
	base "user/base/controllers"
	"user/forms"
	"user/services"
)

type UserController struct {
	base.RequiredAuthController // 封装了 Prepare函数的controller
}

// 会在所有的函数执行前进行检查
// func (c *UserController) Prepare() {
// 	user := c.GetSession("user")
// 	if user == nil {
// 		// session等于nil 那就属于未登录,然后重定向到登录页面
// 		c.Redirect("/auth/login", 302)
// 		return // 保证后面的代码不执行
// 	}
// }

func (c *UserController) Add() {
	if c.Ctx.Input.IsPost() {
		var form forms.AddUserForm
		c.ParseForm(&form)
		services.AddUser(form.Name, form.Password, form.Addr, form.Sex)
		c.Redirect("/user/query", 302)
	} else {
		c.Data["form"] = &forms.AddUserForm{Name: ""}
		c.TplName = "user/add.html"
	}
}

func (c *UserController) Query() {
	c.Data["users"] = services.GetUsers()
	c.TplName = "user/query.html"
}

func (c *UserController) Delete() {
	if id, err := c.GetInt64("id"); err == nil {
		services.DeleteUser(id)
	}
	c.Redirect("/user/query", 302)
}
